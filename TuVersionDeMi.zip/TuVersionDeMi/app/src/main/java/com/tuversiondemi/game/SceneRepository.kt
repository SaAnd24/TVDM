package com.tuversiondemi.game

import android.content.Context
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException

/** Carga y valida assets/scenes.json con org.json (incluido en Android). */
object SceneRepository {
    private const val FILE = "scenes.json"

    fun load(context: Context): SceneData {
        return try {
            val raw = context.assets.open(FILE).bufferedReader(Charsets.UTF_8).use { it.readText() }
            parse(raw)
        } catch (e: IOException) {
            GameLog.e("No se pudo leer assets/$FILE", e)
            SceneData("", emptyMap(), listOf("No se pudo leer $FILE"))
        }
    }

    fun parse(raw: String): SceneData {
        val problems = mutableListOf<String>()
        fun problem(msg: String) {
            problems.add(msg)
            GameLog.e("scenes.json: $msg")
        }

        val root = try {
            JSONObject(raw)
        } catch (e: JSONException) {
            GameLog.e("scenes.json no es JSON válido", e)
            return SceneData("", emptyMap(), listOf("JSON inválido: ${e.message}"))
        }

        val start = root.optString("start", "").trim()
        val chapter = root.optString("chapter", "")
        val arr = root.optJSONArray("scenes")
        if (arr == null) {
            problem("Falta la lista 'scenes'")
            return SceneData(start, emptyMap(), problems, chapter)
        }

        val scenes = LinkedHashMap<String, Scene>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i)
            if (o == null) {
                problem("scenes[$i] no es un objeto")
                continue
            }
            val id = o.optString("id", "").trim()
            if (id.isEmpty()) {
                problem("scenes[$i] no tiene id")
                continue
            }
            if (scenes.containsKey(id)) {
                problem("Id duplicado: $id")
                continue
            }
            val text = o.optString("text", "")
            if (text.isBlank()) problem("Escena $id sin texto")

            val next = o.optString("next", "").trim().ifEmpty { null }
            val choices = mutableListOf<Choice>()
            val ca = o.optJSONArray("choices")
            if (ca != null) {
                for (j in 0 until ca.length()) {
                    val c = ca.optJSONObject(j)
                    val ct = c?.optString("text", "")?.trim().orEmpty()
                    val target = c?.optString("target", "")?.trim().orEmpty()
                    if (ct.isEmpty() || target.isEmpty()) {
                        problem("Escena $id: opción $j incompleta")
                        continue
                    }
                    choices.add(Choice(ct, target))
                }
            }
            if (next != null && choices.isNotEmpty()) {
                problem("Escena $id tiene next y choices; se usarán solo las opciones")
            }
            scenes[id] = Scene(
                id = id,
                speaker = o.optString("speaker", "").trim(),
                text = text,
                next = if (choices.isEmpty()) next else null,
                choices = choices
            )
        }

        if (start.isEmpty() || !scenes.containsKey(start)) problem("'start' inválido: '$start'")
        for (s in scenes.values) {
            s.next?.let { if (!scenes.containsKey(it)) problem("Escena ${s.id}: next '$it' no existe") }
            for (c in s.choices) {
                if (!scenes.containsKey(c.target)) problem("Escena ${s.id}: destino '${c.target}' no existe")
            }
        }

        if (scenes.containsKey(start)) {
            val seen = HashSet<String>()
            val queue = ArrayDeque<String>()
            queue.add(start)
            while (queue.isNotEmpty()) {
                val id = queue.removeFirst()
                if (!seen.add(id)) continue
                val s = scenes[id] ?: continue
                s.next?.let { queue.add(it) }
                s.choices.forEach { queue.add(it.target) }
            }
            for (id in scenes.keys) {
                if (id !in seen) {
                    problems.add("Escena inaccesible: $id")
                    GameLog.w("scenes.json: escena inaccesible: $id")
                }
            }
        }

        GameLog.i("Escenas cargadas: ${scenes.size}, problemas: ${problems.size}")
        return SceneData(start, scenes, problems, chapter)
    }
}

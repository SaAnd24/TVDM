package com.tuversiondemi.game

/**
 * Motor narrativo: sabe qué escena está activa y cómo moverse entre escenas.
 * No depende de Canvas ni de Android UI.
 */
class NarrativeEngine(private val data: SceneData) {

    var current: Scene = errorScene("inicio")
        private set

    private val history = mutableListOf<String>()

    val chapterLabel: String get() = data.chapter

    init {
        restart()
    }

    fun restart() {
        history.clear()
        goTo(data.start)
    }

    /** Avanza a `next`. Devuelve false si la escena actual no tiene `next`. */
    fun advance(): Boolean {
        val n = current.next ?: return false
        goTo(n)
        return true
    }

    /** Elige una opción de la escena actual. */
    fun choose(index: Int): Boolean {
        val c = current.choices.getOrNull(index)
        if (c == null) {
            GameLog.w("Opción $index inexistente en escena ${current.id}")
            return false
        }
        GameLog.i("Elección en ${current.id}: '${c.text}' -> ${c.target}")
        goTo(c.target)
        return true
    }

    private fun goTo(id: String) {
        val s = data.scenes[id]
        if (s == null) {
            GameLog.e("Escena inexistente: '$id' (desde '${current.id}'). Ruta: $history")
            current = errorScene(id)
            return
        }
        history.add(id)
        current = s
        GameLog.i("Escena activa: $id")
    }

    private fun errorScene(id: String) = Scene(
        id = "__error__",
        speaker = "Sistema",
        text = "No se pudo cargar la escena «$id». Revisa el log (etiqueta TVDM) o reinicia.",
        next = null,
        choices = emptyList()
    )
}

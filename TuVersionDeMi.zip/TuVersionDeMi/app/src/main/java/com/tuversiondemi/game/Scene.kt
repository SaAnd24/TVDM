package com.tuversiondemi.game

/** Una opción que el jugador puede elegir. `target` es el id de la escena destino. */
data class Choice(val text: String, val target: String)

/**
 * Una escena = una pantalla de texto.
 * - speaker vacío => narración.
 * - next != null => al tocar se avanza a esa escena.
 * - choices no vacío => el jugador debe elegir (tiene prioridad sobre next).
 * - sin next ni choices => escena final (se ofrece reiniciar).
 */
data class Scene(
    val id: String,
    val speaker: String,
    val text: String,
    val next: String?,
    val choices: List<Choice>
) {
    val isEnding: Boolean get() = next == null && choices.isEmpty()
}

/** Contenido narrativo cargado. `problems` = errores/avisos de validación. */
data class SceneData(
    val start: String,
    val scenes: Map<String, Scene>,
    val problems: List<String>,
    val chapter: String = ""
)

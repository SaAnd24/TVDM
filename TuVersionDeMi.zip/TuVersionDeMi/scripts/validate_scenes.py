#!/usr/bin/env python3
"""Valida app/src/main/assets/scenes.json: ids únicos, destinos existentes, escenas alcanzables."""
import json, sys

PATH = "app/src/main/assets/scenes.json"
errors, warnings = [], []

try:
    with open(PATH, encoding="utf-8") as f:
        data = json.load(f)
except Exception as e:
    print(f"ERROR: no se pudo leer {PATH}: {e}")
    sys.exit(1)

scenes = {}
for i, s in enumerate(data.get("scenes", [])):
    sid = (s.get("id") or "").strip()
    if not sid:
        errors.append(f"scenes[{i}] sin id"); continue
    if sid in scenes:
        errors.append(f"id duplicado: {sid}"); continue
    if not (s.get("text") or "").strip():
        errors.append(f"{sid}: sin texto")
    if s.get("next") and s.get("choices"):
        warnings.append(f"{sid}: tiene next y choices (se usarán solo choices)")
    scenes[sid] = s

start = data.get("start", "")
if start not in scenes:
    errors.append(f"start inválido: '{start}'")

for sid, s in scenes.items():
    n = s.get("next")
    if n and n not in scenes:
        errors.append(f"{sid}: next '{n}' no existe")
    for j, c in enumerate(s.get("choices", [])):
        if not c.get("text") or not c.get("target"):
            errors.append(f"{sid}: opción {j} incompleta")
        elif c["target"] not in scenes:
            errors.append(f"{sid}: destino '{c['target']}' no existe")

seen, stack = set(), [start]
while stack:
    cur = stack.pop()
    if cur in seen or cur not in scenes: continue
    seen.add(cur)
    s = scenes[cur]
    if s.get("next"): stack.append(s["next"])
    stack += [c.get("target") for c in s.get("choices", [])]
for sid in scenes:
    if sid not in seen:
        warnings.append(f"escena inaccesible: {sid}")

for w in warnings: print("AVISO:", w)
for e in errors: print("ERROR:", e)
print(f"{len(scenes)} escenas, {len(errors)} errores, {len(warnings)} avisos")
sys.exit(1 if errors else 0)

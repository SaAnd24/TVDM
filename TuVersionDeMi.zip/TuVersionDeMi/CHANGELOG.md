# CHANGELOG

## 0.1.0 — Base funcional
- Proyecto Android completo (Kotlin nativo, una Activity, vista Canvas), sin dependencias de terceros.
- Pantalla de título y primera conversación jugable Vera/Gael (47 escenas, 2 puntos de decisión con variaciones que convergen).
- Motor narrativo desacoplado (`NarrativeEngine`), carga y validación de `scenes.json` (`SceneRepository`).
- Botones de Inicio y Reiniciar; escena final con botón de reinicio.
- Registro `GameLog` (logcat TVDM + archivo `tvdm_log.txt`).
- Workflow de GitHub Actions: valida escenas y compila APK debug.
- README con biblia narrativa, mecánicas, arquitectura, roadmap y protocolo de continuidad.
- NO probado: la compilación y la ejecución en dispositivo no se han realizado al crear esta versión. Solo se ejecutó `scripts/validate_scenes.py`.

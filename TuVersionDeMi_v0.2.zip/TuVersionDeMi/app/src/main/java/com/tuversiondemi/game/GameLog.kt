package com.tuversiondemi.game

import android.content.Context
import android.util.Log
import java.io.File
import java.io.IOException

/**
 * Registro sencillo: escribe en logcat (etiqueta TVDM) y en un archivo
 * tvdm_log.txt dentro de la carpeta de archivos externos de la app
 * (Android/data/com.tuversiondemi.game/files/), legible sin PC.
 */
object GameLog {
    const val TAG = "TVDM"
    private const val MAX_FILE_BYTES = 100_000L
    private var file: File? = null

    fun attach(context: Context) {
        try {
            val dir = context.getExternalFilesDir(null) ?: context.filesDir
            val f = File(dir, "tvdm_log.txt")
            if (f.exists() && f.length() > MAX_FILE_BYTES) f.delete()
            file = f
            i("Log de archivo: ${f.absolutePath}")
        } catch (e: SecurityException) {
            Log.e(TAG, "No se pudo preparar el archivo de log", e)
        }
    }

    fun i(msg: String) = write("I", msg, null)
    fun w(msg: String) = write("W", msg, null)
    fun e(msg: String, t: Throwable? = null) = write("E", msg, t)

    private fun write(level: String, msg: String, t: Throwable?) {
        when (level) {
            "I" -> Log.i(TAG, msg)
            "W" -> Log.w(TAG, msg)
            else -> Log.e(TAG, msg, t)
        }
        val detail = if (t != null) " | ${t.javaClass.simpleName}: ${t.message}" else ""
        val line = "${System.currentTimeMillis()} $level $msg$detail\n"
        try {
            file?.appendText(line)
        } catch (ex: IOException) {
            Log.e(TAG, "No se pudo escribir en el archivo de log", ex)
        }
    }
}

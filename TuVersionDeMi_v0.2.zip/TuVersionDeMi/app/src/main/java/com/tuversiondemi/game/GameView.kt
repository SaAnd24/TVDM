package com.tuversiondemi.game

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View

/**
 * Dibuja el estado actual (título o escena) con Canvas y traduce toques en acciones
 * del NarrativeEngine. No contiene lógica narrativa.
 */
class GameView(
    context: Context,
    private val engine: NarrativeEngine,
    private val problemCount: Int
) : View(context) {

    private enum class Phase { TITLE, PLAYING }

    private var phase = Phase.TITLE

    private fun dp(v: Float): Float = v * resources.displayMetrics.density
    private fun sp(v: Float): Float =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)

    // Paleta sobria
    private val colBgTop = Color.parseColor("#0E1118")
    private val colBgBottom = Color.parseColor("#1B2230")
    private val colBox = Color.parseColor("#E61A1F2B")
    private val colBoxLine = Color.parseColor("#3A4458")
    private val colText = Color.parseColor("#ECE8E1")
    private val colMuted = Color.parseColor("#9AA3B2")
    private val colVera = Color.parseColor("#D9A55B")
    private val colGael = Color.parseColor("#6FA3D8")
    private val colButton = Color.parseColor("#2A3448")
    private val colWarn = Color.parseColor("#E0867A")

    private val bgPaint = Paint()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1.5f)
        color = colBoxLine
    }
    private val titleP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = colText; textSize = sp(38f); typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        textAlign = Paint.Align.CENTER; letterSpacing = 0.05f
    }
    private val subP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = colMuted; textSize = sp(14f); textAlign = Paint.Align.CENTER
    }
    private val textP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = colText; textSize = sp(18f); typeface = Typeface.SERIF
    }
    private val narrP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = colMuted; textSize = sp(17f); typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC)
    }
    private val nameP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = sp(14f); typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD); letterSpacing = 0.1f
    }
    private val choiceP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = colText; textSize = sp(16f); typeface = Typeface.SANS_SERIF
    }
    private val btnP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = colText; textSize = sp(15f); textAlign = Paint.Align.CENTER; typeface = Typeface.SANS_SERIF
    }
    private val smallP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = colMuted; textSize = sp(12f); typeface = Typeface.SANS_SERIF
    }
    private val pillP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = sp(12f); typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        letterSpacing = 0.08f; textAlign = Paint.Align.CENTER
    }

    // Fondos: presente (neutro) y recuerdo (neutro / Gael / Vera)
    private val shaders = HashMap<String, LinearGradient>()
    private val tints = mapOf(
        "present" to Pair(colBgTop, colBgBottom),
        "memory" to Pair(Color.parseColor("#15121C"), Color.parseColor("#2B2434")),
        "gael" to Pair(Color.parseColor("#0A1420"), Color.parseColor("#1B2E45")),
        "vera" to Pair(Color.parseColor("#1A120A"), Color.parseColor("#3A2A18"))
    )
    private fun bgKey(): String {
        if (phase != Phase.PLAYING) return "present"
        val sc = engine.current
        return when {
            !sc.isMemory -> "present"
            sc.perspective.isNotEmpty() -> sc.perspective
            else -> "memory"
        }
    }

    // Zonas táctiles de la última pantalla dibujada
    private val homeRect = RectF()
    private val restartRect = RectF()
    private val startRect = RectF()
    private val choiceRects = ArrayList<RectF>()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        shaders.clear()
        for ((k, v) in tints) {
            shaders[k] = LinearGradient(0f, 0f, 0f, h.toFloat(), v.first, v.second, Shader.TileMode.CLAMP)
        }
    }

    override fun onDraw(canvas: Canvas) {
        bgPaint.shader = shaders[bgKey()] ?: shaders["present"]
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
        try {
            if (phase == Phase.TITLE) drawTitle(canvas) else drawGame(canvas)
        } catch (e: RuntimeException) {
            GameLog.e("Error al dibujar (fase $phase, escena ${engine.current.id})", e)
        }
    }

    // ---------- Título ----------
    private fun drawTitle(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawText("TU VERSIÓN", w / 2, h * 0.30f, titleP)
        c.drawText("DE MÍ", w / 2, h * 0.30f + dp(52f), titleP)
        c.drawText("drama psicológico · versión 0.2", w / 2, h * 0.30f + dp(92f), subP)

        val bw = dp(250f)
        val bh = dp(58f)
        startRect.set(w / 2 - bw / 2, h * 0.60f, w / 2 + bw / 2, h * 0.60f + bh)
        drawButton(c, startRect, "Toca para comenzar", colVera)

        if (problemCount > 0) {
            subP.color = colWarn
            c.drawText("$problemCount problemas en scenes.json (ver log TVDM)", w / 2, h - dp(40f), subP)
            subP.color = colMuted
        }
    }

    // ---------- Escena ----------
    private fun drawGame(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val scene = engine.current

        // Barra superior
        val m = dp(12f)
        val bh = dp(48f)
        homeRect.set(m, m, m + dp(100f), m + bh)
        restartRect.set(w - m - dp(120f), m, w - m, m + bh)
        drawButton(c, homeRect, "Inicio", colButton)
        drawButton(c, restartRect, "Reiniciar", colButton)
        smallP.textAlign = Paint.Align.CENTER
        c.drawText(engine.chapterLabel, w / 2, m + bh + dp(22f), smallP)
        drawModePill(c, scene, w / 2, m + bh + dp(32f))
        val topLimit = m + bh + dp(72f)

        // Caja de diálogo (se calcula primero su altura)
        val boxM = dp(12f)
        val pad = dp(16f)
        val innerW = (w - 2 * boxM - 2 * pad).toInt()
        val isNarr = scene.speaker.isEmpty()
        val textLayout = layoutOf(scene.text, if (isNarr) narrP else textP, innerW)

        val labels: List<String> = when {
            scene.choices.isNotEmpty() -> scene.choices.map { it.text }
            scene.isEnding -> listOf("Volver a empezar la escena")
            else -> emptyList()
        }
        val btnInnerW = innerW - dp(24f).toInt()
        val btnLayouts = labels.map { layoutOf(it, choiceP, btnInnerW) }
        val bottom = h - dp(16f)

        // Si no cabe (muchos botones en pantallas bajas) se usa un diseño compacto.
        var compact = false
        var btnHeights = btnLayouts.map { maxOf(it.height + dp(24f), dp(52f)) }
        var gap = dp(10f)
        var contentH = boxContentHeight(isNarr, textLayout.height, btnHeights, gap, pad)
        if (bottom - contentH < topLimit && btnHeights.isNotEmpty()) {
            compact = true
            btnHeights = btnLayouts.map { maxOf(it.height + dp(16f), dp(44f)) }
            gap = dp(6f)
            contentH = boxContentHeight(isNarr, textLayout.height, btnHeights, gap, pad)
        }
        if (compact) GameLog.w("Diseño compacto en escena ${scene.id} (pantalla baja)")

        val top = bottom - contentH
        val box = RectF(boxM, top, w - boxM, bottom)

        // Escenario provisional: dos siluetas
        val stageTop = topLimit
        val stageBottom = top - dp(20f)
        if (stageBottom - stageTop > dp(200f)) {
            drawFigure(c, w * 0.27f, stageBottom, "VERA", colVera, scene.speaker == "Vera")
            drawFigure(c, w * 0.73f, stageBottom, "GAEL", colGael, scene.speaker == "Gael")
        }

        fill.color = colBox
        c.drawRoundRect(box, dp(14f), dp(14f), fill)
        c.drawRoundRect(box, dp(14f), dp(14f), line)

        var y = top + pad
        if (!isNarr) {
            nameP.color = when (scene.speaker) {
                "Vera" -> colVera
                "Gael" -> colGael
                else -> colMuted
            }
            c.drawText(scene.speaker.uppercase(), boxM + pad, y + dp(14f), nameP)
            y += dp(26f)
        }
        c.save()
        c.translate(boxM + pad, y)
        textLayout.draw(c)
        c.restore()
        y += textLayout.height

        choiceRects.clear()
        if (btnLayouts.isEmpty()) {
            smallP.textAlign = Paint.Align.RIGHT
            c.drawText("toca para continuar", w - boxM - pad, y + dp(24f), smallP)
        } else {
            y += dp(8f)
            for (i in btnLayouts.indices) {
                val r = RectF(boxM + pad, y, w - boxM - pad, y + btnHeights[i])
                choiceRects.add(r)
                fill.color = colButton
                c.drawRoundRect(r, dp(10f), dp(10f), fill)
                c.drawRoundRect(r, dp(10f), dp(10f), line)
                c.save()
                c.translate(r.left + dp(12f), r.top + (r.height() - btnLayouts[i].height) / 2)
                btnLayouts[i].draw(c)
                c.restore()
                y += btnHeights[i] + gap
            }
        }
    }

    private fun boxContentHeight(isNarr: Boolean, textH: Int, btnH: List<Float>, gap: Float, pad: Float): Float {
        var h = pad
        if (!isNarr) h += dp(26f)
        h += textH
        if (btnH.isEmpty()) {
            h += dp(36f)
        } else {
            h += dp(8f)
            for (b in btnH) h += b + gap
        }
        return h + pad - dp(4f)
    }

    /** Etiqueta "PRESENTE" / "RECUERDO" (+ versión activa) centrada en cx, con su borde en y. */
    private fun drawModePill(c: Canvas, scene: Scene, cx: Float, yTop: Float) {
        val label = when {
            !scene.isMemory -> "PRESENTE · ARCHIVO"
            scene.perspective == "gael" -> "RECUERDO · VERSIÓN DE GAEL"
            scene.perspective == "vera" -> "RECUERDO · VERSIÓN DE VERA"
            else -> "RECUERDO · ESTACIÓN"
        }
        val col = when {
            !scene.isMemory -> colMuted
            scene.perspective == "gael" -> colGael
            scene.perspective == "vera" -> colVera
            else -> colText
        }
        val pw = pillP.measureText(label) + dp(28f)
        val ph = dp(26f)
        val r = RectF(cx - pw / 2, yTop, cx + pw / 2, yTop + ph)
        fill.color = Color.parseColor("#80000000")
        c.drawRoundRect(r, ph / 2, ph / 2, fill)
        line.color = col
        c.drawRoundRect(r, ph / 2, ph / 2, line)
        line.color = colBoxLine
        pillP.color = col
        val fm = pillP.fontMetrics
        c.drawText(label, cx, r.centerY() - (fm.ascent + fm.descent) / 2, pillP)
    }

    private fun drawFigure(c: Canvas, cx: Float, baseY: Float, label: String, color: Int, active: Boolean) {
        val alpha = if (active) 255 else 80
        fill.color = color
        fill.alpha = alpha
        val bodyTop = baseY - dp(110f)
        c.drawRoundRect(RectF(cx - dp(34f), bodyTop, cx + dp(34f), baseY), dp(18f), dp(18f), fill)
        c.drawCircle(cx, bodyTop - dp(30f), dp(26f), fill)
        smallP.textAlign = Paint.Align.CENTER
        smallP.alpha = alpha
        c.drawText(label, cx, bodyTop - dp(66f), smallP)
        smallP.alpha = 255
        fill.alpha = 255
    }

    private fun drawButton(c: Canvas, r: RectF, text: String, color: Int) {
        fill.color = color
        c.drawRoundRect(r, dp(12f), dp(12f), fill)
        c.drawRoundRect(r, dp(12f), dp(12f), line)
        val fm = btnP.fontMetrics
        btnP.color = if (color == colVera) Color.parseColor("#1A1308") else colText
        c.drawText(text, r.centerX(), r.centerY() - (fm.ascent + fm.descent) / 2, btnP)
    }

    private fun layoutOf(text: String, paint: TextPaint, width: Int): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, paint, maxOf(width, 1))
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(0f, 1.15f)
            .build()

    // ---------- Táctil ----------
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            try {
                handleTap(event.x, event.y)
            } catch (e: RuntimeException) {
                GameLog.e("Error al procesar toque en escena ${engine.current.id}", e)
            }
            invalidate()
            performClick()
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun handleTap(x: Float, y: Float) {
        if (phase == Phase.TITLE) {
            engine.restart()
            phase = Phase.PLAYING
            return
        }
        when {
            homeRect.contains(x, y) -> phase = Phase.TITLE
            restartRect.contains(x, y) -> engine.restart()
            choiceRects.isNotEmpty() -> {
                val i = choiceRects.indexOfFirst { it.contains(x, y) }
                if (i >= 0) {
                    if (engine.current.choices.isNotEmpty()) engine.choose(i) else engine.restart()
                }
            }
            else -> engine.advance()
        }
    }

    /** Devuelve true si consumió el botón Atrás. */
    fun onBack(): Boolean {
        if (phase == Phase.PLAYING) {
            phase = Phase.TITLE
            invalidate()
            return true
        }
        return false
    }
}

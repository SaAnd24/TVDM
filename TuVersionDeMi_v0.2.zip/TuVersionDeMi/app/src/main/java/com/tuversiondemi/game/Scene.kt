package com.tuversiondemi.game

/** Una opción que el jugador puede elegir. `target` es el id de la escena destino. */
data class Choice(val text: String, val target: String)

/**
 * Una escena = una pantalla de texto.
 * - speaker vacío => narración.
 * - next != null => al tocar se avanza a esa escena.
 * - choices no vacío => el jugador debe elegir (tiene prioridad sobre next).
 * - sin next ni choices => escena final (se ofrece reiniciar).
 * - mode (v0.2): "present" (por defecto) o "memory". Solo cambia cómo se dibuja la escena.
 * - perspective (v0.2): "" (ninguna), "gael" o "vera". Solo cambia cómo se dibuja la escena;
 *   la perspectiva activa se codifica en el grafo de escenas, no en un estado del motor.
 */
data class Scene(
    val id: String,
    val speaker: String,
    val text: String,
    val next: String?,
    val choices: List<Choice>,
    val mode: String = MODE_PRESENT,
    val perspective: String = ""
) {
    val isEnding: Boolean get() = next == null && choices.isEmpty()
    val isMemory: Boolean get() = mode == MODE_MEMORY

    companion object {
        const val MODE_PRESENT = "present"
        const val MODE_MEMORY = "memory"
        val MODES = setOf(MODE_PRESENT, MODE_MEMORY)
        val PERSPECTIVES = setOf("", "gael", "vera")
    }
}

/** Contenido narrativo cargado. `problems` = errores/avisos de validación. */
data class SceneData(
    val start: String,
    val scenes: Map<String, Scene>,
    val problems: List<String>,
    val chapter: String = "",
    /** Etiqueta por capítulo según el prefijo del id (p. ej. "c2" para "c2_01"). */
    val chapters: Map<String, String> = emptyMap()
)

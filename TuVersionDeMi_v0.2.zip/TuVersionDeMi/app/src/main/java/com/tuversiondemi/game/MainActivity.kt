package com.tuversiondemi.game

import android.app.Activity
import android.os.Bundle

class MainActivity : Activity() {

    private var gameView: GameView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        GameLog.attach(this)
        GameLog.i("Inicio de MainActivity")
        val data = SceneRepository.load(this)
        val engine = NarrativeEngine(data)
        val view = GameView(this, engine, data.problems.size)
        gameView = view
        setContentView(view)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        // Atrás en la partida vuelve al título; en el título cierra la app.
        if (gameView?.onBack() != true) super.onBackPressed()
    }
}

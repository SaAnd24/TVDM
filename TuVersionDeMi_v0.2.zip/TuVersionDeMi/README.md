# TU VERSIÓN DE MÍ

> Documento canónico y fuente de continuidad del proyecto. Una cuenta nueva de Claude/ChatGPT debe poder retomarlo solo con este archivo y el código.

## A. Identidad del proyecto
- **Título:** TU VERSIÓN DE MÍ
- **Género:** drama psicológico, ciencia ficción íntima, aventura narrativa 2D para Android.
- **Premisa:** en un futuro cercano se pueden extraer y eliminar recuerdos autobiográficos, pero son reconstrucciones subjetivas, no grabaciones. Vera, revisora en un archivo de memorias, recibe la solicitud de su hermano Gael (seis años sin hablarse) para borrar el día en que se fue de casa.
- **Objetivo narrativo:** que el jugador se encariñe con ambos, comprenda sus contradicciones y cuestione sus propias interpretaciones.
- **Tecnología:** Kotlin nativo, Android SDK, una Activity, vista personalizada con Canvas, 100 % offline, Gradle, GitHub Actions. Sin Compose, sin motores, sin dependencias externas, sin IA ni Internet en el juego.
- **Estado actual:** **versión 0.2.0** (ver sección I).
- **Condición de desarrollo:** el desarrollador trabaja solo desde un móvil Android con Claude + GitHub Actions. Prioridad: sencillez, cambios pequeños, errores localizables.

## B. Biblia narrativa
**Tono:** íntimo, humano, cinematográfico; diálogos breves con subtexto; humor sutil, complicidad, silencios. Evitar melodrama permanente, frases artificialmente profundas, monólogos, explicaciones redundantes, villanos y conspiraciones.

**Mundo/tecnología:** futuro cercano. El procedimiento extrae un recuerdo y lo elimina. El expediente conserva lo que la persona percibió, sintió y recuerda, con omisiones e interpretaciones. La tecnología puede eliminar un recuerdo pero **no puede determinar quién tenía razón**. Vera revisa expedientes y reconstrucciones antes de la eliminación definitiva.

**Historia previa (cronología):**
1. Adolescencia de Vera: es aceptada en un programa de diseño en otra ciudad y lo rechaza. Nunca se lo muestra a Gael.
2. Años de situación familiar difícil que Vera sostiene; Gael lo sabe y evita enfrentarlo.
3. Hace 6 años: Gael consigue una beca de música y sonido. Vera le dice que debe irse y que no está obligado a quedarse por ella.
4. Día de la despedida (estación de autobuses): discuten. Gael recuerda: «Si te vas ahora, no vuelvas esperando que todo siga igual». Para él significa que Vera lo sacó de su vida. Vera recuerda haberlo animado a marcharse; su recuerdo está incompleto.
5. Poco después Vera solicita eliminar ese recuerdo y **cancela el procedimiento** antes de completarlo.
6. Seis años de silencio.
7. Presente (Capítulo 1): Gael solicita eliminar la despedida y autoriza a Vera a revisar el expediente. Vera no se aparta del caso (se dice que por responsabilidad profesional; en realidad quiere saber si él lo recuerda como ella).

**Conflicto central:** dos recuerdos con partes verdaderas y dos interpretaciones distintas. Ninguno es el único culpable.

**Revelación principal (núcleo temático, no sustituir):** Vera pidió borrar ese recuerdo hace seis años y canceló. Además existe una carta de admisión al programa de diseño que rechazó. La verdad: tenía miedo de fracasar fuera, de abandonar a su familia y de descubrir que quería algo más que ser la responsable. Convirtió el miedo en sacrificio y el sacrificio en resentimiento. Gael no le robó el futuro, pero marcharse le resultó más fácil que quedarse y Vera usó esa diferencia para juzgarlo. Gael también contribuyó: sabía que ella sufría y interpretó su silencio como permiso para no enfrentarlo. **Ambos simplificaron el pasado.** Prohibido sustituirla por conspiración, infidelidad, enfermedad secreta o giro sobrenatural.

**Temas:** recordar un hecho ≠ comprenderlo; resentimiento por sacrificios no expresados; querer a quien nos hiere con su interpretación; autonomía y derecho a decidir aunque duela; responsabilidad sin culpabilidad absoluta; reconciliarse sin recuperar la relación anterior; derecho a no perdonar; olvidar el dolor ≠ aprender a vivir con él.

**Pregunta temática central:** «Si pudieras eliminar el recuerdo de la peor cosa que alguien te dijo, ¿también borrarías la versión de esa persona que todavía quieres?»

**Diálogo de referencia tonal (conservar):**
> GAEL: ¿Sigues trabajando de noche? / VERA: Alguien tiene que revisar los recuerdos de las personas que no pueden dormir. / GAEL: Siempre fuiste buena encontrando motivos para quedarte despierta. / VERA: Y tú siempre fuiste bueno encontrando motivos para marcharte. / (Silencio) / GAEL: No vine a discutir. / VERA: Ya lo sé. / GAEL: Quiero dejar de recordar aquella tarde cada vez que pienso en volver. / VERA: ¿Y si la recuerdas de otra manera? / GAEL: No quiero que me cambies el recuerdo, Vera. Quiero que dejes de necesitar que sea distinto al tuyo. / (Vera no encuentra una respuesta inmediata.)

*(Este diálogo está implementado casi íntegro en el Capítulo 1 de la 0.1.)*

## C. Fichas de personajes
### Vera Mena (28)
- **Personalidad:** responsable, práctica, difícil de engañar; la que resuelve cuando los demás se van.
- **Historia:** rechazó estudiar diseño en otra ciudad; se contó que se sacrificó por su familia.
- **Motivación:** saber si su hermano recuerda lo mismo que ella; sostener su versión.
- **Defecto:** convierte sus decisiones personales en obligaciones que los demás le deben.
- **Contradicción:** le dijo que era libre de irse, pero parte de ella esperaba que se quedara.
- **Relación:** quiere a Gael; lo juzga por la facilidad con que se fue.
- **Sabe/ignora:** Cap. 1: sabe que lleva 6 años sin hablar con Gael y que la despedida acabó mal; cree (o dice creer) que nunca intentó detenerlo; *ignora* (se niega a ver) su propio miedo. Cap. 2: ve que sus gestos se leen de otra forma. Cap. 3: confronta la solicitud cancelada y la carta. Cap. 4: decide cómo afrontarlo.
- **No revelar aún al jugador (Cap. 1-2):** la solicitud de eliminación cancelada, la carta de admisión y el verdadero motivo.

### Gael Mena (24)
- **Personalidad:** sensible, evasivo con lo difícil, buen oído (música y sonido).
- **Historia:** beca de música y sonido lejos; construyó una vida propia sin sentirse libre de la familia.
- **Motivación:** dejar de sentir el dolor de aquella tarde; que Vera reconozca que marcharse tuvo un precio.
- **Defecto:** evita las conversaciones difíciles hasta que ya no queda con quién tenerlas.
- **Contradicción:** quiere dejar atrás la culpa y a la vez necesita que Vera la reconozca.
- **Relación:** disfrutaba de su hermana; interpretó seis años su silencio como rechazo.
- **Sabe/ignora:** sabe la frase que recuerda y que ella pasaba dificultades; *ignora* la carta, la solicitud cancelada y que Vera esperaba que se quedara. Cap. 1: no pide reconciliación, pide trámite.
- **No revelar aún:** que eligió no enfrentarse a las dificultades de Vera (se descubre en Cap. 2-3).

### Relación
Se conocen a fondo: bromas privadas (ej.: llamar «eficiente» a lo que sale mal, invención de la 0.1, compatible con el canon), rutinas, complicidad. Deben existir escenas donde se note que disfrutaban de la compañía mutua. No fueron enemigos permanentes. Personajes adicionales: **Nuria** (compañera del archivo, solo mencionada en 0.1); no crear más sin decisión explícita.

## D. Estructura de la historia (4 capítulos breves)
1. **El expediente** — Presenta a Vera, el archivo y la tecnología; llega Gael; seis años sin hablar; interpretaciones distintas. Termina cuando Vera abre el expediente. *(0.1 implementa este capítulo en versión reducida.)*
2. **El mismo día** — Se examina la despedida desde la perspectiva de Gael y de Vera. Objetos: billete de autobús, bolsa de Gael, carta doblada. Algunos detalles coinciden, otros cambian de sentido. Ejemplo: Gael recuerda que Vera evita mirarlo al subir al autobús; Vera recuerda que aparta la mirada porque va a llorar. Sin cámara omnisciente que decida quién tiene razón.
3. **Lo que elegimos olvidar** — Vera encuentra su antigua solicitud y la carta de admisión. Decide: revelar a Gael, justificar el pasado o respetar su decisión sin usar esos documentos para convencerlo.
4. **La última versión** — Gael decide si elimina. Vera decide cómo afronta su responsabilidad y si respeta la autonomía de él. El desenlace depende de las acciones previas.

## E. Finales canónicos (ninguno implementado en 0.1; solo diseño)
1. **El archivo vacío** (trágico). Vera se aferra a su versión y usa lo descubierto para probar que Gael también fue responsable. Gael confirma la eliminación y se va sin que se comprendan. Condiciones previstas: `presiono_gael` y no `admitio_miedo`.
2. **Sin aquella noche** (agridulce). Vera admite por qué se quedó y que convirtió su decisión en reproche. Gael elimina igualmente. Sin perdón automático ni relación anterior, pero acuerdan que quizá puedan volver a hablar. Condiciones: `admitio_miedo` y eliminación confirmada.
3. **Dos versiones** (esperanzador). Ambos conservan sus recuerdos. Vera acepta que Gael no adopte su interpretación; Gael deja de usar la suya como explicación de seis años de silencio. Salen juntos sin promesas imposibles; empiezan una conversación pendiente. Condiciones: `admitio_miedo` y `respeto_eliminacion` y Gael no elimina.
4. **La petición cancelada** (devastador, con revelación final). El jugador evita investigar el expediente de Vera. Gael elimina y se va. Después Vera encuentra su solicitud antigua y comprende que también intentó borrar aquella tarde pero canceló: conservó el recuerdo porque no sabía quién sería si dejaba de castigarse con él. La revelación llega cuando ya no puede modificar la conversación. Condición: no `investigo_solicitud_vera`.
No son «buenos» o «malos»: cada uno responde a una forma de afrontar dolor, verdad y autonomía.

## F. Mecánicas
**Existentes en 0.1:**
- Interacción por Canvas y toques: tocar para avanzar; elegir opción tocando el botón; botones **Inicio** y **Reiniciar** arriba; tecla Atrás vuelve al título.
- Sistema de diálogos: escenas con hablante (o narración en cursiva), texto y siguiente escena u opciones.
- Escenas y transiciones por identificador; dos decisiones (`c1_choice1`, `c1_choice2`) con pequeñas variaciones que convergen (`c1_comun1`, `c1_fin1`).
- Escena final con botón «Volver a empezar la escena».
- Gráficos provisionales: dos siluetas (ámbar = Vera, azul = Gael); la que habla se ilumina.

**Añadidas en 0.2:**
- Transición presente → recuerdo (escenas `c2_01`…`c2_07`) y regreso (`c2_exit_1`, `c2_ret_*`). Etiqueta superior PRESENTE / RECUERDO (+ «VERSIÓN DE GAEL/VERA») y tinte de fondo distinto (neutro, azul = Gael, ámbar = Vera).
- Selector de perspectiva `c2_sel` (Gael = el del expediente; Vera = el suyo propio) y botón «Cambiar a la versión de …» en cada hub.
- Hub por perspectiva (`c2_g_hub`, `c2_v_hub`) con 5 botones: examinar billete / bolsa / carta, cambiar de versión, salir del recuerdo.
- Inspección de objetos: cada objeto son 3 escenas (`c2_<g|v>_<tk|bg|lt>_1..3`); la última tiene el botón «Volver a la estación» al hub de la misma perspectiva.
- **Gestión de la perspectiva sin estado:** la perspectiva activa está codificada en el grafo (hub y objetos distintos por versión). El motor no guarda nada nuevo, así que Reiniciar/Inicio no pueden dejar estados temporales. Al cambiar de versión se rejuega la conversación de esa versión antes de su hub.
- Las dos versiones comparten gestos y líneas (ej. «Te acostumbrarás», no mirar al subir al autobús) con significados distintos. No se declara cuál es exacta.
- Decisión de contenido 0.2: **la carta doblada del recuerdo tiene contenido deliberadamente indefinido**. En la versión de Gael Vera la sostiene casi toda la despedida; en la de Vera nunca sale del bolsillo y ella no recuerda haberla sacado. No se afirma que sea la carta de admisión. Debe resolverse en 0.4 sin contradecir ninguna de las dos versiones.

**Solo planificadas (NO existen):** comparación avanzada de perspectivas (0.3-0.4), indicadores narrativos (0.3), guardado/recuperación (0.3), revelar/ocultar información (0.4), finales (0.5).

**Indicadores narrativos futuros** (hechos explícitos, nunca barras de afecto): `revelo_carta`, `admitio_miedo`, `respeto_eliminacion`, `investigo_solicitud_vera`, `presiono_gael`.

## G. Arquitectura y archivos
Paquete `com.tuversiondemi.game` en `app/src/main/java/com/tuversiondemi/game/`:
| Archivo | Función | Dónde añadir cosas nuevas |
|---|---|---|
| `MainActivity.kt` | Única Activity; carga escenas, crea motor y vista, gestiona Atrás | Integración con Android (guardado, ciclo de vida) |
| `GameView.kt` | Dibuja con Canvas y traduce toques en acciones | Nuevos elementos visuales / nuevas zonas táctiles |
| `NarrativeEngine.kt` | Escena activa, avanzar, elegir, reiniciar. Sin dependencia de Canvas | Indicadores, condiciones, efectos de decisiones (0.3) |
| `Scene.kt` | Modelos `Scene` (con `mode`, `perspective`), `Choice`, `SceneData` (con `chapters`) | Nuevos campos del JSON |
| `SceneRepository.kt` | Lee `assets/scenes.json` con `org.json`, valida | Nuevas validaciones |
| `GameLog.kt` | Log a logcat (TVDM) y a `tvdm_log.txt` | — |
| `assets/scenes.json` | **Contenido narrativo** | Escenas nuevas: solo editar aquí |
| `scripts/validate_scenes.py` | Validador offline (también en el workflow) | Reglas nuevas en paralelo a SceneRepository |
| `scripts/test_playthrough.py` | Pruebas de recorrido del grafo (simula la navegación del motor en Python; no ejecuta Kotlin) | Nuevas rutas a probar |
| `.github/workflows/android.yml` | CI | — |

**Formato de `scenes.json`:**
```json
{ "chapter": "CAPÍTULO 1 · EL EXPEDIENTE",
  "start": "c1_01",
  "scenes": [
    { "id": "c1_08", "speaker": "Gael", "text": "¿Sigues trabajando de noche?", "next": "c1_09" },
    { "id": "c1_choice1", "speaker": "", "text": "¿Qué responde Vera?",
      "choices": [ { "text": "Opción A", "target": "c1_a1" }, { "text": "Opción B", "target": "c1_b1" } ] }
  ] }
```
Campos opcionales (0.2): `mode` = `present` (por defecto) o `memory`; `perspective` = `gael`/`vera` (solo con `memory`); en la raíz, `chapters` = `{ "c1": "…", "c2": "…" }` (la etiqueta se elige por el prefijo del id). Solo afectan al dibujado y a la validación.

Reglas: `id` único y estable; `speaker` vacío = narración (otros nombres: «Vera», «Gael»); `next` o `choices` (si hay ambos, mandan las opciones); sin ninguno = escena final; todo destino debe existir. Convención de ids: `c<capítulo>_<nombre>`. Un destino inexistente no cierra la app: se registra el error y se muestra una escena «Sistema» con el id problemático. El título muestra un aviso si hay problemas de validación.

**Decisiones técnicas:** una sola Activity que extiende `android.app.Activity` (sin AppCompat, para cero dependencias); `org.json` en vez de bibliotecas; sin bucle de juego (la vista solo se redibuja al tocar); texto con `StaticLayout`; tamaños en dp/sp para adaptarse a densidades; orientación vertical fija.

## H. Compilación e instalación
**Configuración elegida (compatible entre sí):** Gradle 8.7 · Android Gradle Plugin 8.5.2 · Kotlin 1.9.24 · Java 17 · compileSdk/targetSdk 34 · minSdk 24. No cambiar versiones sin razón concreta. El repositorio **no incluye gradle wrapper**: el workflow instala Gradle 8.7 con `gradle/actions/setup-gradle`.

**Pasos desde el móvil:**
1. Sube el contenido del ZIP (descomprimido, con `.github/` incluido) a un repositorio de GitHub, en la rama `main`.
2. Pestaña **Actions** → «Android Debug APK» → **Run workflow** (también se ejecuta solo en cada push a `main`).
3. Abre la ejecución terminada → sección **Artifacts** → `TuVersionDeMi-debug-apk` (descarga un ZIP con `app-debug.apk`).
4. Descomprime, abre el APK y permite «instalar apps de origen desconocido» para tu gestor de archivos/navegador.

**Errores comunes de compilación:**
- *Step «Validar escenas» falla:* error en `scenes.json` (el mensaje indica id y problema).
- *«Unresolved reference» en Kotlin:* revisa nombres o imports del archivo indicado en el log.
- *«SDK location not found» / licencias:* los runners de GitHub traen el SDK; si ocurre, revisar el paso de compilación completo.
- *Incompatibilidad AGP/Gradle/Java:* respetar la tabla de versiones.
- *No aparece el artifact:* el paso de compilación falló; abrirlo y leer las últimas líneas.

**Registros:** logcat (etiqueta `TVDM`) y archivo `Android/data/com.tuversiondemi.game/files/tvdm_log.txt` en el teléfono (lo puede abrir un gestor de archivos; en algunas versiones de Android esa carpeta está restringida).

**Reproducir un problema:** pulsa **Reiniciar** en cualquier escena (o **Inicio** y tocar para empezar) y repite la secuencia; el log registra cada escena y elección.

## I. Registro del estado actual (0.2.0)
- **Implementado:** todo lo de F («Existentes» y «Añadidas en 0.2»). Escenas: 47 (v0.1) → **112** (v0.2; 66 nuevas, `c1_fin3` eliminada).
- **Incompleto (por diseño):** estado narrativo persistente, guardado, finales, arte definitivo, sonido.
- **Verificado automáticamente (en el entorno de desarrollo):**
  - `scripts/validate_scenes.py` → 112 escenas, 0 errores, 0 avisos (ids únicos, referencias válidas, todo alcanzable, sin ciclos solo-`next`, toda escena alcanza un final, todo recuerdo regresa al presente, estructura de hubs, textos distintos por perspectiva). Se comprobó con una mutación deliberada que el validador detecta referencias cruzadas y campos inválidos.
  - `scripts/test_playthrough.py` → 8 pruebas de recorrido correctas: llegada al recuerdo desde las 9 combinaciones de decisiones del cap. 1, 3 objetos × 2 perspectivas con regreso al hub, cambio de perspectiva en ambos sentidos, salida al presente y final, volver a mirar el recuerdo, reinicio desde el recuerdo.
- **NO verificado (no se pudo):** compilación con Gradle/Kotlin (el entorno no tiene kotlinc, Gradle ni red) — el código Kotlin nuevo está sin compilar; el APK no se ha generado aquí; ejecución en teléfono; dibujado del banner, tintes, modo compacto y áreas táctiles; legibilidad de textos en pantallas reales.
- **Pruebas manuales en el teléfono:** ver sección M.
- **Errores/limitaciones conocidas:** (1) el hub tiene 5 botones; en pantallas muy bajas se usa diseño compacto, pero no hay scroll; (2) al cambiar de versión se rejuega la conversación de esa versión (no se va directo al hub); (3) no se marca qué objetos ya se examinaron; (4) los botones de fin dicen «Volver a empezar la escena» pero reinician la partida (heredado de 0.1); (5) tras volver a mirar el recuerdo desde el presente se entra por `c2_07` sin la secuencia de transición completa; (6) `GameLog` puede registrar avisos de diseño compacto en cada redibujado; (7) la carpeta de log puede ser inaccesible en Android 11+.

## J. Roadmap canónico
**0.1 — Base funcional:** proyecto Android, Activity+Canvas, pantalla inicial, primera conversación, escenas y opciones, validación, reinicio y registros, GitHub Actions, README. *Criterio:* APK debug instalable y conversación recorrible.

**0.2 — El primer recuerdo:** recuerdo de la despedida en la estación; objetos examinables; perspectivas de Vera y Gael; primera transición presente→recuerdo; motor e historia separados. *Criterio:* recorrer el recuerdo e inspeccionar sus elementos sin errores de navegación.

**0.3 — Consecuencias y estado:** indicadores narrativos explícitos; decisiones con consecuencias persistentes en la partida; primera bifurcación importante; guardado y recuperación; definir qué se conserva al cerrar. *Criterio:* una decisión produce una consecuencia verificable y el progreso se recupera tras cerrar el juego.

**0.4 — La revelación:** antigua solicitud de Vera; carta de admisión; escenas de investigación; revelar u ocultar información; desarrollo emocional del conflicto. *Criterio:* el jugador descubre la revelación y comprende por qué cambia la interpretación de lo anterior.

**0.5 — Los cuatro finales:** integrar finales; condiciones ligadas a hechos explícitos; verificar rutas alcanzables; detectar condiciones contradictorias y escenas inaccesibles; corregir combinaciones. *Criterio:* cada final alcanzable con una secuencia documentada, sin errores de navegación.

**1.0 — Edición completa:** pulido visual; arte definitivo donde sea viable; transiciones y cuadros de diálogo; legibilidad, rendimiento y táctil; ajustes de lectura; música/sonido opcionales solo si no complican; pruebas de todas las rutas; documentación de publicación. *Criterio:* experiencia completa, estable y probada en dispositivo con los cuatro finales.

No adelantar funcionalidades de versiones posteriores.

## K. Protocolo de continuidad entre cuentas
1. Lee este README completo y `CHANGELOG.md`.
2. Inspecciona el código actual (`app/src/main/java/...`, `scenes.json`, workflow) antes de tocar nada.
3. Respeta el canon narrativo y las decisiones técnicas. Si algo debe cambiar, documéntalo aquí con justificación; no cambies el canon por accidente.
4. Identifica la tarea de la versión actual y mantén el alcance.
5. Cambios pequeños y localizados; no reescribas archivos ni el proyecto por comodidad; no añadas mecánicas no contempladas; no actualices dependencias sin motivo.
6. Después de cada cambio: revisar coherencia entre archivos, ejecutar `python3 scripts/validate_scenes.py`, revisar el workflow, actualizar README (estado real) y CHANGELOG, listar qué probar en el teléfono e indicar qué no se pudo probar. Nunca afirmar pruebas que no se hicieron.
7. No borrar secciones del canon para ahorrar espacio; añadir al historial.

## L. Próximo paso exacto: versión 0.3 — Consecuencias y estado
**Tarea:** (1) compilar la 0.2 en GitHub Actions, instalarla y corregir lo que falle (ver M); (2) añadir un pequeño estado narrativo en `NarrativeEngine` con indicadores explícitos (`presiono_gael`, `admitio_miedo`, `respeto_eliminacion`, …) que se reinicie en `restart()`; (3) ligar al menos una decisión del cap. 1/2 a una consecuencia verificable en el cap. 3 (primera bifurcación); (4) guardado y recuperación del progreso (SharedPreferences) y definir qué se conserva al cerrar; (5) extender validador y pruebas de recorrido a los indicadores y a la bifurcación; (6) opcional: marcar objetos ya examinados.

**Criterios de terminado:** compila en Actions; una decisión produce una consecuencia verificable; el progreso se recupera tras cerrar el juego; Reiniciar limpia el estado; validador y pruebas sin errores; README y CHANGELOG actualizados.

## M. Pruebas manuales pendientes de la 0.2 (en el teléfono)
1. Instalar el APK de Actions; el título dice «versión 0.2».
2. Jugar el cap. 1 y comprobar que tras «Vera se queda a solas…» continúa con el cap. 2 (etiqueta «CAPÍTULO 2 · EL MISMO DÍA», banner «PRESENTE · ARCHIVO»).
3. Ver el cambio a «RECUERDO · ESTACIÓN» con fondo distinto y elegir «El de Gael» o «El suyo propio».
4. En cada hub, examinar los tres objetos y usar «Volver a la estación»; comprobar que el texto cambia según la versión.
5. Cambiar de versión desde el hub y examinar de nuevo los objetos.
6. «Salir del recuerdo» → volver al presente → «Volver a mirar el recuerdo» y «Cerrar el expediente».
7. Probar **Inicio** y **Reiniciar** dentro del recuerdo, dentro de una inspección y en el final; la tecla Atrás vuelve al título.
8. Comprobar que los 5 botones del hub caben, que los textos largos se leen y que las áreas táctiles responden bien.

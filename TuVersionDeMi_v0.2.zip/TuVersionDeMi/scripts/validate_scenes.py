#!/usr/bin/env python3
"""Valida app/src/main/assets/scenes.json: ids únicos, destinos existentes, escenas alcanzables,
campos mode/perspective, ciclos sin interacción, salidas y coherencia de perspectivas (v0.2)."""
import json, sys

PATH = "app/src/main/assets/scenes.json"
errors, warnings = [], []

try:
    with open(PATH, encoding="utf-8") as f:
        data = json.load(f)
except Exception as e:
    print(f"ERROR: no se pudo leer {PATH}: {e}")
    sys.exit(1)

scenes = {}
for i, s in enumerate(data.get("scenes", [])):
    sid = (s.get("id") or "").strip()
    if not sid:
        errors.append(f"scenes[{i}] sin id"); continue
    if sid in scenes:
        errors.append(f"id duplicado: {sid}"); continue
    if not (s.get("text") or "").strip():
        errors.append(f"{sid}: sin texto")
    if s.get("next") and s.get("choices"):
        warnings.append(f"{sid}: tiene next y choices (se usarán solo choices)")
    scenes[sid] = s

start = data.get("start", "")
if start not in scenes:
    errors.append(f"start inválido: '{start}'")

for sid, s in scenes.items():
    n = s.get("next")
    if n and n not in scenes:
        errors.append(f"{sid}: next '{n}' no existe")
    for j, c in enumerate(s.get("choices", [])):
        if not c.get("text") or not c.get("target"):
            errors.append(f"{sid}: opción {j} incompleta")
        elif c["target"] not in scenes:
            errors.append(f"{sid}: destino '{c['target']}' no existe")

seen, stack = set(), [start]
while stack:
    cur = stack.pop()
    if cur in seen or cur not in scenes: continue
    seen.add(cur)
    s = scenes[cur]
    if s.get("next"): stack.append(s["next"])
    stack += [c.get("target") for c in s.get("choices", [])]
for sid in scenes:
    if sid not in seen:
        warnings.append(f"escena inaccesible: {sid}")

# ---- Reglas v0.2 ----
MODES = {"present", "memory"}
PERSP = {"", "gael", "vera"}
def mode(s): return s.get("mode") or "present"
def persp(s): return s.get("perspective") or ""
def edges(s):
    out = [c.get("target") for c in s.get("choices", [])]
    if not out and s.get("next"): out = [s["next"]]
    return [t for t in out if t in scenes]

for sid, s in scenes.items():
    if mode(s) not in MODES: errors.append(f"{sid}: mode '{mode(s)}' inválido")
    if persp(s) not in PERSP: errors.append(f"{sid}: perspective '{persp(s)}' inválida")
    if persp(s) and mode(s) != "memory": errors.append(f"{sid}: perspective solo es válida en mode memory")
    pref = sid.split("_")[0]
    if data.get("chapters") and pref not in data["chapters"]:
        warnings.append(f"{sid}: prefijo '{pref}' sin entrada en 'chapters'")

# Ciclos sin interacción (solo 'next'): el jugador quedaría atrapado sin decidir nada
def has_next_cycle():
    color = {}
    def dfs(u):
        color[u] = 1
        s = scenes[u]
        if not s.get("choices") and s.get("next") in scenes:
            v = s["next"]
            if color.get(v) == 1: return True
            if v not in color and dfs(v): return True
        color[u] = 2
        return False
    return any(u not in color and dfs(u) for u in scenes)
if has_next_cycle():
    errors.append("ciclo sin interacción (solo 'next'): bucle involuntario")

# Desde toda escena alcanzable debe poder llegarse a una escena final (sin trampas)
rev = {sid: [] for sid in scenes}
for sid, s in scenes.items():
    for t in edges(s): rev[t].append(sid)
endings = [sid for sid, s in scenes.items() if not s.get("next") and not s.get("choices")]
can_end, st = set(), list(endings)
while st:
    u = st.pop()
    if u in can_end: continue
    can_end.add(u); st += rev[u]
for sid in seen:
    if sid not in can_end: errors.append(f"{sid}: no conduce a ninguna escena final (trampa)")

# Desde todo recuerdo debe poder regresarse al presente
can_present, st = set(), [sid for sid, s in scenes.items() if mode(s) == "present"]
while st:
    u = st.pop()
    if u in can_present: continue
    can_present.add(u); st += rev[u]
for sid, s in scenes.items():
    if mode(s) == "memory" and sid not in can_present:
        errors.append(f"{sid}: recuerdo sin ruta de regreso al presente")

# Hubs de perspectiva (v0.2): exactamente 3 objetos + cambio + salida; objetos que regresan al mismo hub
for p in ("gael", "vera"):
    hubs = [sid for sid, s in scenes.items() if persp(s) == p and len(s.get("choices", [])) >= 4]
    if len(hubs) != 1:
        errors.append(f"perspectiva {p}: se esperaba 1 hub con >=4 opciones, hay {len(hubs)}"); continue
    hub = hubs[0]
    tg = [c["target"] for c in scenes[hub]["choices"]]
    objs = [t for t in tg if persp(scenes[t]) == p]
    others = [t for t in tg if persp(scenes[t]) != p]
    if len(objs) != 3: errors.append(f"{hub}: se esperaban 3 objetos de su perspectiva, hay {len(objs)}")
    if len(others) != 2: errors.append(f"{hub}: se esperaban 2 salidas (cambio y salir), hay {len(others)}")
    for o in objs:
        cur, steps = o, 0
        while scenes[cur].get("next") and not scenes[cur].get("choices") and steps < 10:
            cur = scenes[cur]["next"]; steps += 1
            if persp(scenes[cur]) != p: errors.append(f"{o}: la cadena de examen sale de la perspectiva {p}")
        back = [c["target"] for c in scenes[cur].get("choices", [])]
        if back != [hub]: errors.append(f"{o}: la inspección no termina con 'volver' a {hub} (termina en {cur} -> {back})")
# Las escenas de una perspectiva no deben enlazar con la otra sin pasar por una escena de transición
for sid, s in scenes.items():
    if persp(s):
        for t in edges(s):
            if persp(scenes[t]) not in ("", persp(s)) and sid != "":
                errors.append(f"{sid}: enlaza directamente con la perspectiva contraria ({t})")
# Cada objeto debe tener texto distinto en cada perspectiva
for kind in ("tk", "bg", "lt"):
    tg = "".join(scenes[f"c2_g_{kind}_{i}"]["text"] for i in (1, 2, 3) if f"c2_g_{kind}_{i}" in scenes)
    tv = "".join(scenes[f"c2_v_{kind}_{i}"]["text"] for i in (1, 2, 3) if f"c2_v_{kind}_{i}" in scenes)
    if not tg or not tv or tg == tv: errors.append(f"objeto {kind}: textos ausentes o idénticos entre perspectivas")

for w in warnings: print("AVISO:", w)
for e in errors: print("ERROR:", e)
print(f"{len(scenes)} escenas, {len(errors)} errores, {len(warnings)} avisos")
sys.exit(1 if errors else 0)

#!/usr/bin/env python3
"""Pruebas de recorrido sobre scenes.json (v0.2).

Simulan en Python la misma lógica de navegación que NarrativeEngine (advance / choose / restart).
NO ejecutan el código Kotlin ni la interfaz Canvas: verifican el grafo de escenas, no la app.
"""
import json, sys

PATH = "app/src/main/assets/scenes.json"
data = json.load(open(PATH, encoding="utf-8"))
SC = {s["id"]: s for s in data["scenes"]}

class Engine:
    def __init__(self): self.restart()
    def restart(self): self.cur = SC[data["start"]]; self.trail = [self.cur["id"]]
    def go(self, i): self.cur = SC[i]; self.trail.append(i)
    def advance(self):
        if self.cur.get("choices") or not self.cur.get("next"): return False
        self.go(self.cur["next"]); return True
    def choose(self, text):
        for c in self.cur.get("choices", []):
            if c["text"] == text: self.go(c["target"]); return True
        raise AssertionError(f"{self.cur['id']}: no hay opción '{text}'. Hay: {[c['text'] for c in self.cur.get('choices', [])]}")
    def run_to_choice_or_end(self, limit=200):
        n = 0
        while self.advance():
            n += 1
            assert n < limit, "posible bucle"
    def mode(self): return self.cur.get("mode", "present")
    def persp(self): return self.cur.get("perspective", "")

fails, passed = [], []
def test(name):
    def deco(fn):
        try: fn(); passed.append(name)
        except AssertionError as e: fails.append(f"{name}: {e}")
        except Exception as e: fails.append(f"{name}: {type(e).__name__}: {e}")
        return fn
    return deco

def to_selector(e, c1a="¿Seguro que quieres hacer esto?", c1b="Asentir, sin decir nada."):
    e.run_to_choice_or_end(); assert e.cur["id"] == "c1_choice1"; e.choose(c1a)
    e.run_to_choice_or_end(); assert e.cur["id"] == "c1_choice2"; e.choose(c1b)
    e.run_to_choice_or_end()

def enter(e, who):
    to_selector(e)
    assert e.cur["id"] == "c2_sel", e.cur["id"]
    e.choose("El de Gael, el del expediente" if who == "gael" else "El suyo propio")
    e.run_to_choice_or_end()
    assert e.persp() == who and e.cur["id"] == f"c2_{who[0]}_hub", e.cur["id"]

@test("2. Se llega al recuerdo desde cada combinación de decisiones del capítulo 1")
def _():
    a = ["Debería apartarme de este caso.", "¿Seguro que quieres hacer esto?", "Pensaba que no volverías."]
    b = ["Revisaré el expediente. Como cualquier otro.", "Dime solo una cosa: ¿qué recuerdas que te dije?", "Asentir, sin decir nada."]
    for x in a:
        for y in b:
            e = Engine(); to_selector(e, x, y)
            assert e.cur["id"] == "c2_sel" and e.mode() == "memory"
            assert any(t.startswith("c2_06") for t in e.trail)

@test("3+4. Tres objetos por perspectiva: se examinan, muestran texto de su perspectiva y regresan al hub")
def _():
    for who in ("gael", "vera"):
        for label in ("Examinar el billete", "Examinar la bolsa", "Examinar la carta doblada"):
            e = Engine(); enter(e, who); hub = e.cur["id"]
            e.choose(label); first = e.cur["id"]
            assert e.persp() == who and first.startswith(f"c2_{who[0]}_"), first
            e.run_to_choice_or_end()
            assert [c["text"] for c in e.cur["choices"]] == ["Volver a la estación"], e.cur["id"]
            e.choose("Volver a la estación")
            assert e.cur["id"] == hub

@test("5. Cambio de perspectiva en ambos sentidos y textos distintos del mismo objeto")
def _():
    e = Engine(); enter(e, "gael")
    e.choose("Examinar el billete"); e.run_to_choice_or_end(); tg = e.cur["text"]; e.choose("Volver a la estación")
    e.choose("Cambiar a la versión de Vera"); e.run_to_choice_or_end()
    assert e.cur["id"] == "c2_v_hub" and e.persp() == "vera"
    e.choose("Examinar el billete"); e.run_to_choice_or_end(); tv = e.cur["text"]; e.choose("Volver a la estación")
    assert tg != tv
    e.choose("Cambiar a la versión de Gael"); e.run_to_choice_or_end()
    assert e.cur["id"] == "c2_g_hub"

@test("5b. Tras cambiar de perspectiva siguen examinables los 3 objetos con el texto nuevo")
def _():
    e = Engine(); enter(e, "gael"); e.choose("Cambiar a la versión de Vera"); e.run_to_choice_or_end()
    seen = set()
    for label in ("Examinar el billete", "Examinar la bolsa", "Examinar la carta doblada"):
        e.choose(label); assert e.persp() == "vera"; e.run_to_choice_or_end(); seen.add(e.cur["id"]); e.choose("Volver a la estación")
    assert len(seen) == 3

@test("6. Salir del recuerdo, volver al presente y llegar al final sin bloqueo")
def _():
    for who in ("gael", "vera"):
        e = Engine(); enter(e, who); e.choose("Salir del recuerdo"); e.run_to_choice_or_end()
        assert e.mode() == "present" and e.cur["id"] == "c2_ret_choice", e.cur["id"]
        e.choose("Cerrar el expediente por esta noche"); e.run_to_choice_or_end()
        assert e.cur["id"] == "c2_fin2" and not e.cur.get("choices") and not e.cur.get("next")

@test("6b. Volver a mirar el recuerdo desde el presente funciona y no se queda atascado")
def _():
    e = Engine(); enter(e, "vera"); e.choose("Salir del recuerdo"); e.run_to_choice_or_end()
    e.choose("Volver a mirar el recuerdo"); e.run_to_choice_or_end()
    assert e.cur["id"] == "c2_sel"
    e.choose("El de Gael, el del expediente"); e.run_to_choice_or_end(); assert e.cur["id"] == "c2_g_hub"

@test("7+8. Reiniciar desde cualquier punto vuelve a c1_01 y no arrastra estado (el motor no guarda perspectiva)")
def _():
    for who in ("gael", "vera"):
        e = Engine(); enter(e, who); e.choose("Examinar la bolsa")
        e.restart(); assert e.cur["id"] == "c1_01" and e.trail == ["c1_01"] and e.mode() == "present" and e.persp() == ""
        enter(e, who)   # la ruta completa vuelve a funcionar tras reiniciar

@test("8. Todas las escenas con perspectiva son alcanzables recorriendo solo opciones y 'next'")
def _():
    seen, st = set(), [data["start"]]
    while st:
        u = st.pop()
        if u in seen: continue
        seen.add(u); s = SC[u]
        st += [c["target"] for c in s.get("choices", [])] or ([s["next"]] if s.get("next") else [])
    missing = [i for i in SC if i not in seen]
    assert not missing, missing

for n in passed: print("OK   ", n)
for f in fails: print("FALLA", f)
print(f"{len(passed)} pruebas correctas, {len(fails)} fallos")
sys.exit(1 if fails else 0)

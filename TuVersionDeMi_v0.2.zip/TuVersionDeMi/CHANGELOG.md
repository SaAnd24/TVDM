# CHANGELOG

## 0.2.0 — El primer recuerdo (Capítulo 2 · El mismo día)
- Nuevo capítulo 2: transición del presente (archivo) al recuerdo de la estación de autobuses y regreso al presente. 66 escenas nuevas; `c1_fin3` (fin de demo) eliminada y `c1_fin2` enlaza con `c2_01`. Total: 47 → 112 escenas.
- Dos perspectivas (Gael / Vera) del mismo recuerdo, con selector de entrada y botón para cambiar desde el hub.
- Tres objetos examinables por perspectiva (billete, bolsa, carta doblada), con texto distinto en cada versión y botón «Volver a la estación».
- `Scene`: campos opcionales `mode` (`present`/`memory`) y `perspective` (`""`/`gael`/`vera`). `scenes.json`: mapa opcional `chapters` (etiqueta por prefijo de id).
- `GameView`: etiqueta PRESENTE/RECUERDO (+ versión activa) y tinte de fondo por modo/perspectiva; diseño compacto si los botones no caben.
- Sin estado nuevo en el motor: la perspectiva activa vive en el grafo de escenas, por lo que Reiniciar no puede dejar estados temporales.
- `validate_scenes.py` ampliado (campos nuevos, ciclos sin interacción, trampas sin final, regreso al presente, estructura de hubs, textos distintos por perspectiva). Nuevo `test_playthrough.py` (8 pruebas de recorrido) y paso nuevo en el workflow.
- Versión de la app 0.2.0 (versionCode 2).
- NO verificado: compilación Kotlin/Gradle y ejecución en teléfono (no había toolchain Android en este entorno). Ver README, sección I.

## 0.1.0 — Base funcional
- Proyecto Android completo (Kotlin nativo, una Activity, vista Canvas), sin dependencias de terceros.
- Pantalla de título y primera conversación jugable Vera/Gael (47 escenas, 2 puntos de decisión con variaciones que convergen).
- Motor narrativo desacoplado (`NarrativeEngine`), carga y validación de `scenes.json` (`SceneRepository`).
- Botones de Inicio y Reiniciar; escena final con botón de reinicio.
- Registro `GameLog` (logcat TVDM + archivo `tvdm_log.txt`).
- Workflow de GitHub Actions: valida escenas y compila APK debug.
- README con biblia narrativa, mecánicas, arquitectura, roadmap y protocolo de continuidad.
- NO probado: la compilación y la ejecución en dispositivo no se han realizado al crear esta versión. Solo se ejecutó `scripts/validate_scenes.py`.
